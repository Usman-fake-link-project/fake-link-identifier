import csv, io, json, os, re, sqlite3
from datetime import datetime
from urllib.parse import urlsplit, urlunsplit
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, Response
import joblib

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,'data','app.db')
MODEL_PATH=os.path.join(BASE,'models','url_model.joblib')
TRUSTED_PATH=os.path.join(BASE,'data','trusted_domains.json')
app=Flask(__name__); app.secret_key=os.environ.get('SECRET_KEY','change-this-secret-key')
with open(TRUSTED_PATH,encoding='utf-8') as f: TRUSTED=json.load(f)
MODEL=joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None
METRICS={'accuracy':'90.82%','macro_f1':'0.8450','roc_auc':'0.9516','fake_recall':'74.76%','legit_recall':'94.35%','false_positives':'4,833','false_negatives':'4,750','threshold':'0.55','model':'Binary Canonical TF-IDF + SGDClassifier'}

@app.context_processor
def ctx():
    return {'project':{'title':'AI-Based Fake Link Identifier','student':'Usman Musa Usman','matric':'U/CS/21/040','institution':'Yobe State University','department':'Department of Computer Science','supervisor':'Dr Audu Musa Maku'}}

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    os.makedirs(os.path.dirname(DB),exist_ok=True); c=db()
    c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT)')
    c.execute('''CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY AUTOINCREMENT,url TEXT,final_class TEXT,fake_probability REAL,legitimate_probability REAL,confidence REAL,status TEXT,risk TEXT,decision_source TEXT,trusted_match TEXT,diagnostics TEXT,created_at TEXT)''')
    c.execute("INSERT OR IGNORE INTO users(username,password) VALUES('admin','admin123')")
    c.commit(); c.close()

def canon(s):
    s=(s or '').strip()
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*://',s): s='http://'+s
    try:
        p=urlsplit(s); scheme=(p.scheme or 'http').lower(); host=(p.hostname or '').lower().rstrip('.')
        port=p.port; net=host
        if port and not ((scheme=='http' and port==80) or (scheme=='https' and port==443)): net+=f':{port}'
        return urlunsplit((scheme,net,p.path or '/',p.query,p.fragment))
    except Exception: return s

def host(u):
    try:return (urlsplit(u).hostname or '').lower().rstrip('.')
    except:return ''

def trusted(u):
    h=host(u)
    for x in TRUSTED:
        d=x['domain'].lower().rstrip('.')
        if x.get('kind','root')=='root' and h in (d,'www.'+d): return x
        if x.get('kind')=='host' and h==d: return x
    return None

def diagnostics(u):
    p=urlsplit(u); h=(p.hostname or '').lower(); s=u.lower(); out=[]
    if p.scheme!='https': out.append('Uses HTTP instead of HTTPS')
    if re.fullmatch(r'\d{1,3}(?:\.\d{1,3}){3}',h): out.append('Hostname is a raw IP address')
    if len(u)>100: out.append('Unusually long URL')
    if h.count('.')>=3: out.append('Deep subdomain structure')
    if h.count('-')>=2: out.append('Multiple hyphens in hostname')
    if '@' in u: out.append('Contains @ delimiter')
    words=['login','verify','verification','secure','account','update','password','signin','bank','payment','wallet','confirm','credential','otp','unlock']
    hits=[w for w in words if w in s]
    if hits: out.append('Sensitive keywords: '+', '.join(sorted(set(hits))))
    return out or ['No major lexical warning observed']

def predict(raw):
    u=canon(raw); tm=trusted(u)
    if MODEL is None: fake=.5; legit=.5
    else:
        p=MODEL.predict_proba([u])[0]; mp={str(c):float(v) for c,v in zip(MODEL.classes_,p)}; fake=mp.get('fake',0.5); legit=mp.get('legitimate',1-fake)
    model_class='Fake Link' if fake>=.55 else 'Legitimate Link'; mx=max(fake,legit); gap=abs(fake-legit)
    status='CONFIDENT' if mx>=.60 and gap>=.20 else 'UNCERTAIN'
    final='Legitimate Link' if tm else model_class
    source='Verified Trusted Official Domain' if tm else 'Machine Learning Model'
    risk='Medium' if status=='UNCERTAIN' else ('High' if final=='Fake Link' else 'Low')
    return {'url':u,'final_class':final,'fake_probability':fake*100,'legitimate_probability':legit*100,'confidence':mx*100,'status':status,'risk':risk,'decision_source':source,'trusted_match':tm.get('organisation','') if tm else '','diagnostics':diagnostics(u),'raw_model_class':model_class}

def save(r):
    c=db(); c.execute('INSERT INTO predictions(url,final_class,fake_probability,legitimate_probability,confidence,status,risk,decision_source,trusted_match,diagnostics,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(r['url'],r['final_class'],r['fake_probability'],r['legitimate_probability'],r['confidence'],r['status'],r['risk'],r['decision_source'],r['trusted_match'],'; '.join(r['diagnostics']),datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC'))); c.commit(); c.close()

def login_required(f):
    @wraps(f)
    def w(*a,**kw): return f(*a,**kw) if session.get('admin') else redirect(url_for('login',next=request.path))
    return w

@app.route('/')
def home(): return render_template('index.html')
@app.route('/analyze',methods=['GET','POST'])
def analyze():
    r=None
    if request.method=='POST':
        u=request.form.get('url','').strip()
        if not u: flash('Please enter a URL.','warning')
        else: r=predict(u); save(r)
    return render_template('analyze.html',result=r)
@app.route('/batch',methods=['GET','POST'])
def batch():
    rows=[]; summary=None
    if request.method=='POST':
        f=request.files.get('file')
        if not f or not f.filename.lower().endswith('.csv'): flash('Upload a CSV containing a url column.','warning')
        else:
            rd=csv.DictReader(io.StringIO(f.read().decode('utf-8-sig','replace')))
            col=next((x for x in (rd.fieldnames or []) if x.strip().lower()=='url'),None)
            if not col: flash("CSV must contain a 'url' column.",'warning')
            else:
                for row in rd:
                    if (v:=row.get(col,'').strip()):
                        r=predict(v); save(r); rows.append(r)
                summary={'total':len(rows),'legit':sum(x['final_class']=='Legitimate Link' for x in rows),'fake':sum(x['final_class']=='Fake Link' for x in rows),'uncertain':sum(x['status']=='UNCERTAIN' for x in rows),'trusted':sum(x['decision_source']=='Verified Trusted Official Domain' for x in rows)}
    return render_template('batch.html',results=rows,summary=summary)
@app.route('/about')
def about(): return render_template('about.html')
@app.route('/performance')
def performance(): return render_template('performance.html',metrics=METRICS)
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        c=db(); r=c.execute('SELECT * FROM users WHERE username=? AND password=?',(request.form.get('username'),request.form.get('password'))).fetchone(); c.close()
        if r: session['admin']=r['username']; return redirect(request.args.get('next') or url_for('dashboard'))
        flash('Invalid username or password.','danger')
    return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('home'))

def counts():
    c=db(); q=lambda s:c.execute(s).fetchone()[0]
    d={'total':q('SELECT COUNT(*) FROM predictions'),'legit':q("SELECT COUNT(*) FROM predictions WHERE final_class='Legitimate Link'"),'fake':q("SELECT COUNT(*) FROM predictions WHERE final_class='Fake Link'"),'uncertain':q("SELECT COUNT(*) FROM predictions WHERE status='UNCERTAIN'"),'high':q("SELECT COUNT(*) FROM predictions WHERE risk='High'"),'medium':q("SELECT COUNT(*) FROM predictions WHERE risk='Medium'"),'low':q("SELECT COUNT(*) FROM predictions WHERE risk='Low'"),'trusted':q("SELECT COUNT(*) FROM predictions WHERE decision_source='Verified Trusted Official Domain'"),'recent':c.execute('SELECT * FROM predictions ORDER BY id DESC LIMIT 8').fetchall()}; c.close(); return d
@app.route('/dashboard')
@login_required
def dashboard(): return render_template('dashboard.html',c=counts(),metrics=METRICS)
@app.route('/history')
@login_required
def history():
    q=request.args.get('q','').strip(); cl=request.args.get('class','All'); risk=request.args.get('risk','All'); sql='SELECT * FROM predictions WHERE 1=1'; args=[]
    if q: sql+=' AND url LIKE ?'; args.append('%'+q+'%')
    if cl in ('Fake Link','Legitimate Link'): sql+=' AND final_class=?'; args.append(cl)
    if risk in ('High','Medium','Low'): sql+=' AND risk=?'; args.append(risk)
    sql+=' ORDER BY id DESC'; c=db(); rows=c.execute(sql,args).fetchall(); c.close(); return render_template('history.html',rows=rows,q=q,cl=cl,risk=risk)
@app.route('/reports')
@login_required
def reports(): return render_template('reports.html',c=counts(),metrics=METRICS)

def csv_response(name,header,rows):
    s=io.StringIO(); w=csv.writer(s); w.writerow(header); w.writerows(rows); return Response(s.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename={name}'})
@app.route('/export-history')
@login_required
def export_history():
    c=db(); rs=c.execute('SELECT id,url,final_class,fake_probability,legitimate_probability,confidence,status,risk,decision_source,trusted_match,diagnostics,created_at FROM predictions ORDER BY id DESC').fetchall(); c.close(); return csv_response('prediction_history.csv',rs[0].keys() if rs else ['id','url'],[list(r) for r in rs])
@app.route('/export-report')
@login_required
def export_report():
    c=counts(); rows=[('Total Analyses',c['total']),('Legitimate Links',c['legit']),('Fake Links',c['fake']),('Uncertain Results',c['uncertain']),('High Risk',c['high']),('Medium Risk',c['medium']),('Low Risk',c['low']),('Trusted Overrides',c['trusted']),('Model Accuracy',METRICS['accuracy']),('Macro F1',METRICS['macro_f1']),('ROC-AUC',METRICS['roc_auc']),('Fake-Link Recall',METRICS['fake_recall'])]; return csv_response('threat_intelligence_report.csv',['Metric','Value'],rows)
@app.route('/export-model-report')
@login_required
def export_model_report(): return csv_response('model_report.csv',['Metric','Value'],list(METRICS.items()))

init_db()
if __name__=='__main__': app.run(debug=True)
