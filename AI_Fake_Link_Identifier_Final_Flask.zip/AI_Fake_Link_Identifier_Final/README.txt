AI-BASED FAKE LINK IDENTIFIER
==============================

Project: Identification of Fake Links Using Machine Learning
Student: Usman Musa Usman
Matric: U/CS/21/040
Institution: Yobe State University
Department: Department of Computer Science
Supervisor: Dr Audu Musa Maku

FEATURES
- Single URL analysis
- Legitimate Link / Fake Link identification
- Fake and legitimate probabilities
- CONFIDENT / UNCERTAIN status
- Low / Medium / High risk
- Exact-match trusted official-domain safeguard
- CSV batch analysis
- Admin login
- Dashboard
- Searchable prediction history
- Threat intelligence reports
- CSV exports
- Model performance page
- Responsive common visual style

MODEL
Binary Canonical TF-IDF + SGDClassifier:
- Character n-grams: 3-5, max 120,000
- Word n-grams: 1-2, max 50,000
- FeatureUnion
- SGDClassifier(loss='log_loss', class_weight='balanced', random_state=42)
- Fake threshold: 0.55

IMPORTANT
This ZIP contains a SMALL DEMONSTRATION MODEL so the application runs immediately.
It is NOT the 522,160-record academic model from the project write-up.

For the final academic model:
1. Put your real malicious_phish.csv in data/
2. It must contain: url,type
3. Run: python train.py
4. The script keeps only benign + phishing, mapping benign -> legitimate and phishing -> fake,
   while excluding malware/defacement.

The Model Performance page shows the metrics reported in the supplied project write-up.
Before final defense/deployment, regenerate metrics from the final trained artifact and update
displayed values if your new training run differs.

DEMO LOGIN
username: admin
password: admin123
Change this before deployment.

LOCAL RUN
python -m venv .venv
pip install -r requirements.txt
python app.py
Then open http://127.0.0.1:5000/

HOSTING
This is a Flask/Python application. It does not run directly on a typical PHP-only shared
hosting web root. Use a Python-capable host for this version.
