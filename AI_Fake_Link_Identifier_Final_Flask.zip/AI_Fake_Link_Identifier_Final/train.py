
import os, re, joblib, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score, f1_score, recall_score, roc_auc_score, classification_report

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data", "malicious_phish.csv")
OUT = os.path.join(BASE, "models", "url_model.joblib")

def canonicalize(s):
    s = str(s).strip()
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", s):
        s = "http://" + s
    return s.lower()

class Predictor:
    def __init__(self, features, classifier):
        self.features = features
        self.classifier = classifier
        self.classes_ = classifier.classes_
    def predict_proba(self, texts):
        return self.classifier.predict_proba(self.features.transform(texts))
    def predict(self, texts):
        return self.classifier.predict(self.features.transform(texts))

df = pd.read_csv(DATA)
df["type"] = df["type"].astype(str).str.lower().str.strip()
df["url"] = df["url"].astype(str).str.strip()
df = df[df["type"].isin(["benign","phishing"])].drop_duplicates(subset=["url"])
df["label"] = df["type"].map({"benign":"legitimate","phishing":"fake"})
df["url"] = df["url"].map(canonicalize)

X_train, X_test, y_train, y_test = train_test_split(
    df["url"], df["label"], test_size=0.20, random_state=42, stratify=df["label"]
)
features = FeatureUnion([
    ("char", TfidfVectorizer(analyzer="char", ngram_range=(3,5), max_features=120000, min_df=2, sublinear_tf=True)),
    ("word", TfidfVectorizer(analyzer="word", ngram_range=(1,2), max_features=50000, min_df=2, sublinear_tf=True)),
])
Xtr = features.fit_transform(X_train)
Xte = features.transform(X_test)
clf = SGDClassifier(loss="log_loss", class_weight="balanced", random_state=42)
clf.fit(Xtr, y_train)
pred = clf.predict(Xte)
probs = clf.predict_proba(Xte)
fake_idx = list(clf.classes_).index("fake")
print("Accuracy:", accuracy_score(y_test,pred))
print("Macro F1:", f1_score(y_test,pred,average="macro"))
print("Fake recall:", recall_score(y_test,pred,pos_label="fake"))
try: print("ROC-AUC:", roc_auc_score((y_test=="fake").astype(int), probs[:,fake_idx]))
except Exception: pass
print(classification_report(y_test,pred))
joblib.dump(Predictor(features, clf), OUT)
print("Saved:", OUT)
